<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/
//1.Главная страница
Route::get('/', function () {
    return view('index');
});


//2.Страница с формой регистрацией
Route::get('/register', function(){
    return view('login');
//    вывод страницы с формой регистрации
})->name('login');
//3.Обработчик формы
Route::post('/register',function(){
//    Обработчик данных
});
//5.Обработчик формы авторизации
Route::post('/login',function(){
//    Обработчик данных
});
//6.Страница с личным кабинетом авторизированного пользователя
Route::get('/lk', function(){
//    вывод персональных данных
});
//7.Страница со списком задач
Route::get('/tasks', function(){
    $tasks = \App\Models\Task::select(['id','name','preview','image','status_id'])->with('status')->get();
    return view('tasks.list', ['tasks'=>$tasks]);
//    вывод списка задач
    return view('tasks.list');
})->name('tasks.list');
//8.Страница с формой создания задачи
Route::get('/tasks/create', function(){
//    вывод формы создания
    return view('tasks.create');
})->name('tasks.create');
//9.Обработчик формы создания задач
Route::post('/tasks/create', function(\Illuminate\Http\Request $request){

//    Обработчик данных
//    считание данные с формы
    $data=$request->all();

//    записать данные в таблицу БД
    $task = new \App\Models\Task();
    $task->name = $data['name'];
    $task->preview = $data['preview'];
    $task->text = $data['text'];
    $task->priority = isset($data['priority']);
    $task->image = $data['file']->store('images');
    $task->status_id = 1;
    $task->save();
//    Перенаправить со списком задач
    return redirect()->route('tasks.list');
})->name('tasks.store');
//10.Страница с детальным описанием задачи
Route::get('/tasks/{task}', function($task){
    $task=\App\Models\Task::with(['status','comments'])->find($task);

    return view('tasks.show', ['task'=>$task]);
//    Вывод данных задачи $task
})->name('tasks.show');
//10.1
Route::post('/tasks/list', function(\Illuminate\Http\Request $request){
    $data=$request->all();
    $comment= new \App\Models\Comment();
    $comment->comment = $data['comment'];
    $comment->save();

    $comment->tasks()->attach($data['select']);

    return redirect()->route('tasks.list');
})->name('comments.store');

//}
//11.Обработчик удаления задачи
Route::delete('/tasks/{task}/delete', function($task){
//    Удаление задачи $task
});
//12.Обработчик смены статуса задачи
Route::patch('/tasks/{task}/status', function($task){
//    Обработчик смены статуса задачи $task
});
//13.Страница с формой редактирования задачи
Route::get('/tasks/{task}/edit', function($task){
//    Вывод формы редактирования задачи $task
});
//14.Обработчик формы редактирования задачи
Route::patch('/tasks/{task}/edit', function($task){
//
});
//15.Обработчик назначения пользователей к задаче
Route::put('/tasks/{task}/user', function($task){
//    Обработчик данных назначения пользователей на задачу $task
});
























/*
Route::get('/test', function(){
   return '<a href="/test/1">Test</a>';
});


Route::get('/test/{id}', function($number){
    return "Вы попали на страницу № $number";
})->whereAlphaNumeric('number');

Route::post('/test', function(){
   //Обработчик формы
    //1. Считывание данных с формы
    //2. сохранение данных в базе
    //3. вывод вьюшки\редирект на другую страницу
});
*/
