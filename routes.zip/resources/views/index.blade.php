@extends('layouts.main')

@section('title', 'Главная страница')

@section('content')
<h1>Главная страница</h1>
@endsection
